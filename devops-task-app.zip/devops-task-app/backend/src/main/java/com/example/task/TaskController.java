package com.example.task;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {
  private final TaskRepository repository;
  public TaskController(TaskRepository repository){this.repository=repository;}

  @GetMapping
  public List<Task> getTasks(){return repository.findAll();}

  @PostMapping
  public Task addTask(@RequestBody Task task){return repository.save(task);}

  @GetMapping("/health")
  public String health(){return "Application is running";}
}
