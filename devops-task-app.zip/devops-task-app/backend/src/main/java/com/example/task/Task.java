package com.example.task;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Task {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
  private Long id;
  private String name;
  public Task(){}
  public Task(String name){this.name=name;}
  public Long getId(){return id;}
  public String getName(){return name;}
  public void setName(String name){this.name=name;}
}
