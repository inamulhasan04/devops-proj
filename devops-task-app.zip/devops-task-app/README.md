# DevOps Task App

A small 3-tier application for practicing Linux, Git/GitHub, Jenkins, SonarQube, Docker, Kubernetes, AWS, Terraform, Ansible, Prometheus and Grafana.

## Application
Frontend: HTML/CSS/JavaScript + Nginx
Backend: Spring Boot REST API
Database: PostgreSQL

## Local
docker compose up --build
Open http://localhost

API health:
http://localhost:8080/api/tasks/health

## Git
git init
git add .
git commit -m "Initial task app"

## Terraform
cd terraform
terraform init
terraform validate
terraform plan -var='ssh_cidr=YOUR_PUBLIC_IP/32'
terraform apply -var='ssh_cidr=YOUR_PUBLIC_IP/32'

## Ansible
Edit ansible/inventory.ini, then:
ansible -i inventory.ini app -m ping
ansible-playbook -i inventory.ini setup.yml

## Kubernetes
Build/load images for your cluster, then:
kubectl apply -f k8s/

## Jenkins/SonarQube
Configure SONAR_HOST_URL and SONAR_TOKEN in Jenkins, then run Jenkinsfile.

## Monitoring
Use monitoring/prometheus.yml as the Prometheus scrape configuration and add Prometheus to Grafana.

## Note
This is a learning/lab project. Production deployments should add HTTPS, private networking, restricted security groups, secret management, an image registry, persistent Kubernetes storage and a managed database.
