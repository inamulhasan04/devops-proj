variable "aws_region" { default = "ap-south-1" }
variable "project_name" { default = "devops-task" }
variable "ssh_cidr" {
  description = "Your public IP in CIDR format, e.g. 203.0.113.10/32"
  type = string
}
