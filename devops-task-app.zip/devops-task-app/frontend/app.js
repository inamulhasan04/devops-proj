const API_URL="/api/tasks";

async function loadTasks(){
  try{
    const response=await fetch(API_URL);
    if(!response.ok) throw new Error("Failed to load tasks");
    const tasks=await response.json();
    const list=document.getElementById("taskList");
    list.innerHTML="";
    tasks.forEach(task=>{
      const li=document.createElement("li");
      li.textContent=`${task.id} - ${task.name}`;
      list.appendChild(li);
    });
  }catch(error){console.error(error);}
}

async function addTask(){
  const input=document.getElementById("taskInput");
  const taskName=input.value.trim();
  if(!taskName){alert("Please enter a task");return;}
  const response=await fetch(API_URL,{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({name:taskName})
  });
  if(!response.ok){alert("Could not add task");return;}
  input.value="";
  loadTasks();
}
loadTasks();
